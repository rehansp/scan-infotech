$(document).ready(function(){
    $("#Loader").show();
    var url = "http://192.168.0.159/IMS/API/ManufacturingJournal.aspx/GetReport";
    var emptyData = null;
    // var ID = 0;
    var TrNo = "TP000001";
    var CreatedBy = "1";
    var CompanyID = "1";

    $.ajax({
        type: "POST",
        url: url,
        cache: false,
        data: JSON.stringify({
        "TrNo" : TrNo,     
        "CreatedBy" : CreatedBy,
        "CompanyID": CompanyID
    }),
        contentType: "application/json",
        dataType: "json",
        success: function (data) {
            emptyData = data;
            console.log(emptyData);

            if(data.d[0].CompanyName != ''){
                $("#CompanyName").append(data.d[0].CompanyName);
            }

            if(data.d[0].HeadOfficeAddress1!=''){
                $("#Address").append(data.d[0].HeadOfficeAddress1, " ", data.d[0].HeadOfficeAddress2, " ", data.d[0].HeadOfficeAddress3);
            }

            if(data.d[0].HeadOfficeBranch!=''){
                $("#Branch").prepend("Branch : ");
                $("#Branch").append(data.d[0].HeadOfficeBranch);
            }
    
            if(data.d[0].HeadOfficePAN!=''){
                $("#PAN").prepend("PAN : ");
                $("#PAN").append(data.d[0].HeadOfficePAN);
            }

            if(data.d[0].HeadOfficeEmail!=''){
                $("#Email").prepend("Email : ");
                $("#Email").append(data.d[0].HeadOfficeEmail);
            }

            if(data.d[0].HeadOfficeTelNo1!=''){
                $("#Contact").prepend("Contact : ");
                $("#Contact").append(data.d[0].HeadOfficeTelNo1);
            }

            if(data.d[0].HeadOfficeMSMEUAN!='')
            {
                $("#MSME").prepend("MSMEUAN NO: ");
                $("#MSME").append(data.d[0].HeadOfficeMSMEUAN);
            }

            if(data.d[0].HeadOfficeGSTINNo!='')
            {
                $("#GST").prepend("GSTIN/UIN : ");
                $("#GST").append(data.d[0].HeadOfficeGSTINNo);
            }

            if(data.d[0].HeadOfficeStateName!=''){
                $("#State").prepend("State Name : ");
                $("#State").append(data.d[0].HeadOfficeStateName, ", ",data.d[0].HeadOfficeStateCode);
            }

            if(data.d[0].HeadOfficeCINNo!=''){
                $("#CIN").prepend("CIN : ");
                $("#CIN").append(data.d[0].HeadOfficeCINNo);
            }
 
            if(data.d[0].HeadOfficeTelNo1!=''){
                $("#ContactNo").prepend("Contact No: ");
                $("#ContactNo").append(data.d[0].HeadOfficeTelNo1);
            }
          
        $("#dateRow").append("<td style = 'text-align: right;'  colspan = '4'>Dated :</td>" +"<td style = 'text-align: right; font-weight : bold;'>"+data.d[0].PostingDate + "</td>")
    
        $("#MainTable").append("<tr><tr style = 'height : 30px;'></tr><tr><td style = 'border: none'>"+ "<b><u>Source (Consumption)</u></b>" +"</td></tr>");

            var scrtotalqty = 0;
            for (var i = 0; i < data.d.length; i++) {                           
                if (data.d[i].ProductType === "SRC") {
                    $("#MainTable").append("<tr><td style = '/*border: 0.5px solid #000;*/ border: none;  width:60%;'>" + data.d[i].ProductName + "</td><td style = '/*border: 0.5px solid #000;*/  border: none; width:10%;'>" + data.d[i].Branch + "</td><td style = '/*border: 0.5px solid #000;*/  border: none; width:10%;'>" + data.d[i].BatchName + "</td><td style = '/*border: 0.5px solid #000;*/  border: none; text-align: right; width:10%;'> " + data.d[i].Qty + "</td><td style = '/*border: 0.5px solid #000;*/  border: none; width:10%;'>" + data.d[i].SRCUOM + "</td></tr>");
                    scrtotalqty = data.d[i].TotalQty;
                }
            }
            $("#MainTable").append("<tr style = 'height : 20px;'></tr>");
            $("#MainTable").append("<tr><td style = 'text-align: center; border-bottom : none;'>" + /*"<b>"  + "Total" + "</b>"*/ "</td><td style = 'border-bottom: none;'>" + "</td><td style = 'border-bottom: none;'>" + "</td><td style = 'text-align: right; border: 0.5px solid #000; border-left: none; border-right: none;'>" +  "<b>" +  scrtotalqty + "</b>" +  "</td><td style = 'border: 0.5px solid #000; border-left:none; border-right: none;'>" + "</td></tr>" ); 
            
            var destotalcnt = 0;
          
            $("#MainTable").append("<tr><tr style = 'height : 30px;'></tr><tr><td  style = 'border: none; width : 60%;'>"+ "<b><u>Destination (Production)</u></b>" +"</td></tr>") 
        
            for (var j = 0; j < data.d.length; j++) {                           
                if (data.d[j].ProductType === "DES") {
                    $("#MainTable").append("<tr><td style = '/*border: 0.5px solid #000;*/ border: none; width:60%;'> " + data.d[j].ProductName + "</td><td style = '/*border: 0.5px solid #000;*/ border: none; width:10%;'>" + data.d[j].Branch + "</td><td style = '/*border: 0.5px solid #000;*/border: none; width:10%;'>" + data.d[j].BatchName + "</td><td style = '/*border: 0.5px solid #000;*/ text-align: right; border: none; width:10%;'> " + data.d[j].Qty + "</td><td style = '/*border: 0.5px solid #000;*/ border: none; width:10%;'>" + data.d[j].DESUOM + "</td></tr>");
                    destotalcnt = data.d[j].TotalQty;
                }                         
            }
            $("#MainTable").append("<tr style = 'height : 20px;'></tr>");
            $("#MainTable").append("<tr><td style = 'text-align: center; border-bottom: none'>" + /*"<b>"  + "Total" + "</b>"*/  "</td><td style = 'border-bottom: none'>" + "</td><td style = 'border-bottom: none'>" + "</td><td style = 'text-align: right; border: 0.5px solid #000; border-left: none; border-right: none;'>" +  "<b>" +  destotalcnt + "</b>" +  "</td><td style = 'border: 0.5px solid #000; border-left:none; border-right: none;'>" + "</td></tr>" ); 
        },

        error: function (jqXHR, textStatus, errorThrown) {
            alert('Error: ' + textStatus + ' - ' + errorThrown);
        }
    });
    $("#Loader").hide();
    $("#divData").show();
    return emptyData;
    });